const createDiningAreasTable =
    require("./schema/diningAreas");
const createRestaurantsTable = require("./schema/restaurants");
const createUsersTable = require("./schema/users");
const createTablesTable =

    require("./tables/createTablesTable");
const {
    createKitchenTables
} = require("./schema/kitchenTickets");    
const createMenuCategoriesTable = require("./schema/menuCategories");
const createMenuItemsTable = require("./schema/menuItems");
const createOrdersTable =
    require("./orders/createOrdersTable");

const createOrderItemsTable =
    require("./orders/createOrderItemsTable");
const runMigrations =
    require("../migrations");    
const createStaffTable =

    require("./schema/staff");

const createPlansTable =
    require("./schema/plans");       
   
const createPlanLimitsTable =
    require("./schema/planLimits");
 
const createSystemCategoriesTable =
    require("./schema/systemCategories");

const createSystemMenuItemsTable =
    require("./schema/systemMenuItems");

const seedSystemMenu =
    require("./seed/systemMenuSeed");  

const createQuickItemsTable =
    require("./schema/quickItems");  
const createOrderStaffParticipantsTable =
    require("./schema/orderStaffParticipants"); 
const createPaymentSplitsTable =
    require("./schema/paymentSplits"); 
const createStaffSessionsTable =
    require("./schema/staffSessions");
                  
async function initializeDatabase() {
    console.log("📦 Initializing database...");

await createRestaurantsTable();

await createUsersTable();

await createDiningAreasTable();

await createTablesTable();

await createMenuCategoriesTable();

await createMenuItemsTable();

await createQuickItemsTable();

await createStaffTable();

await createStaffSessionsTable();

await createSystemCategoriesTable();

await createSystemMenuItemsTable();

await createPlansTable();

await createPlanLimitsTable();

await createOrdersTable();

await createOrderItemsTable();

await createOrderStaffParticipantsTable();

await createPaymentSplitsTable();

await createKitchenTables();

await runMigrations();

await seedSystemMenu();


    console.log("✅ Database initialization completed.");
}

module.exports = initializeDatabase;

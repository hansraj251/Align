const fs = require("fs");
const path = require("path");
const archiver = require("archiver");

const packageJson = require("../package.json");

const outputFile =
    path.join(
        __dirname,
        "..",
        "release",
        `AlignPOS-${packageJson.version}.zip`
    );
const cloudPosFolder =
    path.join(
        __dirname,
        "..",
        "..",
        "Align",
        "storage",
        "pos"
    );

const cloudZip =
    path.join(
        cloudPosFolder,
        "AlignPOS.zip"
    );

const cloudLatest =
    path.join(
        cloudPosFolder,
        "latest.json"
    );    

const output =
    fs.createWriteStream(outputFile);

const archive =
    archiver(
        "zip",
        {
            zlib: {
                level: 9
            }
        }
    );

output.on(
    "close",
    () => {

        fs.copyFileSync(
            outputFile,
            cloudZip
        );

        fs.writeFileSync(
            cloudLatest,
            JSON.stringify(
                {
                    version:
                        packageJson.version,
                    build: 1,
                    mandatory: false,
                    releaseDate:
                        new Date()
                            .toISOString()
                            .split("T")[0],
                    notes: [
                        "Latest POS Release"
                    ]
                },
                null,
                4
            )
        );

        console.log(
            "✅ Release created"
        );

        console.log(
            "✅ Copied to Cloud"
        );

    }
);

archive.on(
    "error",
    err => {

        throw err;

    }
);

archive.pipe(output);

archive.glob(
    "**/*",
    {
        cwd:
            path.join(
                __dirname,
                ".."
            ),
        ignore: [

            "node_modules/**",

            ".git/**",

            "release/**",

            ".env",

            "database/*.db",

            "uploads/**"

        ]
    }
);

archive.finalize();
module.exports = async (db) => {

    try {

        await db.runAsync(`
            ALTER TABLE restaurants
            ADD COLUMN cloud_token TEXT
        `);

    } catch (err) {

        if (
            !err.message.includes(
                "duplicate column name"
            )
        ) {

            throw err;

        }

    }

    try {

        await db.runAsync(`
            ALTER TABLE restaurants
            ADD COLUMN cloud_token_updated_at DATETIME
        `);

    } catch (err) {

        if (
            !err.message.includes(
                "duplicate column name"
            )
        ) {

            throw err;

        }

    }

};
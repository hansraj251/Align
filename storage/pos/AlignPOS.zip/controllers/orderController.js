const db = require("../db");
const orderService =
    require("../services/orderService");
const orderRepository =
    require("../repositories/orderRepository"); 
const orderCalculationService =
    require("../services/orderCalculationService");       
exports.createOrder = (req, res) => {

    const restaurantId = req.user.restaurantId;

    const { table_id } = req.body;

    if (!table_id) {
        return res.status(400).json({
            success: false,
            message: "Table is required"
        });
    }

    db.run(
        `
        INSERT INTO orders
        (
            restaurant_id,
            table_id
        )
        VALUES (?, ?)
        `,
        [
            restaurantId,
            table_id
        ],
        function (err) {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: err.message
                });
            }

            return res.json({
                success: true,
                message: "Order created successfully",
                orderId: this.lastID
            });

        }
    );

};
exports.getActiveOrder = async (req, res) => {

    try {

        const order =
            await orderService.getActiveOrderByTable(

                req.user.restaurantId,

                req.params.tableId

            );

        res.json({

            success: true,

            hasActiveOrder: !!order,

            order

        });

    } catch (err) {
console.error(err);
        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
exports.getOrder = async (req, res) => {

    try {

        const result =
            await orderService.getOrder(

                req.user.restaurantId,

                req.params.orderId

            );

        res.json(result);

    } catch (err) {
console.error(err);
        res.status(404).json({

            success: false,

            message: err.message

        });

    }

};
exports.getOrderHistory = async (
    req,
    res
) => {

    try {

        const result =
            await orderService.getOrderHistory(

                req.user.restaurantId,

                req.query.from,

                req.query.to

            );

        res.json(result);

    } catch (err) {
console.error(err);
        res.status(500).json({

            success: false,

            message: err.message

        });

    }

};
exports.updateDiscount = async (
    req,
    res
) => {

    try {

        let discount =
            Number(req.body.discount);

        if (isNaN(discount)) {
            discount = 0;
        }

        if (discount < 0 || discount > 100) {

            return res.status(400).json({

                success: false,

                message:
                    "Discount must be between 0 and 100."

            });

        }

        await orderRepository.updateDiscount(

            req.params.id,

            discount

        );

        const totals =
            await orderCalculationService.calculateOrderTotals(
                req.params.id
            );

        await orderRepository.updateOrderTotals(
            req.params.id,
            totals
        );

        res.json({
            success: true,
            totals
        });

    } catch (err) {

        res.status(500).json({
            success: false,
            message: err.message
        });

    }

};
exports.sendToBilling = async (
    req,
    res
) => {

    try {

        const result =
            await orderService.sendToBilling(
                req.params.orderId
            );

        res.json(result);

    }

    catch (err) {

        console.error(err);

        res.status(400).json({

            success: false,

            message: err.message

        });

    }

};
exports.serveOrderItem = async (req, res) => {

    try {

        const result =
            await orderRepository.serveOrderItem(

                Number(req.params.id)

            );

        if (!result.success) {

            return res.json(result);

        }

        res.json({

            success: true

        });

    }

    catch (err) {

        console.error(err);

        res.json({

            success: false,

            message: err.message

        });

    }

};

exports.removeQuickItem = async (
    req,
    res
) => {

    try {
       

        const result =
            await orderService.removeQuickItem(
    req.user.restaurantId,
    Number(req.params.orderItemId)
);

        res.json(result);

    }
    catch (err) {

        res.status(400).json({

            success: false,

            message: err.message

        });

    }

};

exports.closeOrder = async (
    req,
    res
) => {

    try {

        const result =
            await orderService.closeOrder(
                req.user.restaurantId,
                Number(req.params.orderId)
            );

        res.json(result);

    }
    catch (err) {

        res.status(400).json({

            success: false,

            message: err.message

        });

    }

};
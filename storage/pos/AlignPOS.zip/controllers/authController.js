const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const db =
    require("../db");
const defaultSetupService =
require("../services/defaultSetupService");

const cloudAuthService =
    require("../services/cloudAuthService");  
const cloudApiService =
    require("../services/cloudApiService");


exports.login = (req, res) => {

    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            success: false,
            message: "Email and Password are required"
        });
    }

    db.get(
        `SELECT * FROM users WHERE email = ?`,
        [email],
        async (err, user) => {
             
            try {

            if (err) {
                return res.status(500).json({
                    success: false,
                    message: "Database error"
                });
            }

            if (!user) {

    try {

        await cloudAuthService.login(
            email,
            password
        );

        user =
            await db.getAsync(
                `
                SELECT *
                FROM users
                WHERE email = ?
                `,
                [email]
            );

    }
    catch (err) {

        return res.status(401).json({

            success: false,

            message:
                "Invalid email or password"

        });

    }

}

if (!user) {

    return res.status(401).json({

        success: false,

        message:
            "Invalid email or password"

    });

}

const passwordMatched = await bcrypt.compare(
    password.trim(),
    user.password.trim()
);


if (!passwordMatched) {
    return res.status(401).json({
        success: false,
        message: "Invalid email or password"
    });
}
await defaultSetupService.ensureDefaultTakeAway(
    user.restaurant_id
);

            const token = jwt.sign(
    {
        userId: user.id,
        restaurantId: user.restaurant_id,
        role: user.role
    },
    process.env.JWT_SECRET,
    {
        expiresIn: "7d"
    }
);

try {

    if (user.role === "owner") {

        await cloudApiService.syncSubscription(
            user.restaurant_id
        );

    }

} catch (err) {

    console.error(
        "Subscription sync failed:",
        err.message
    );

}

return res.json({
    success: true,
    message: "Login Successful",
    token,
    user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
    }
});
        } catch (err) {

            return res.status(403).json({

                success: false,

                message: err.message

            });

        }

        }
    );

};


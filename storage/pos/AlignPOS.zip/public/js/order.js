let allMenuItems = [];

let filteredMenuItems = [];

let selectedCategory = "all";

let selectedFoodType = "all";
const selectedVariants = {};
let currentOrder = null;
let isTakeAway = false;
let currentNoteItem = null;

if (!API.getToken()) {
    window.location.href = "/login.html";
}

const params =
    new URLSearchParams(
        window.location.search
    );
let areaId =
    Number(
        params.get("area")
    );
const kitchenBtn =
    document.getElementById("kitchenBtn");

if (kitchenBtn) {

    kitchenBtn.onclick = () => {

const areaName =
    document.getElementById("areaTitle")?.textContent || "";

window.location.href =
    `/admin/kitchen.html?area=${areaId}&name=${encodeURIComponent(areaName)}`;

    };

}    
const goBack = () => {

    window.location.href =
        `/admin/area.html?id=${areaId}`;

};

document
    .getElementById("backBtn")
    ?.addEventListener(
        "click",
        goBack
    );

document
    .getElementById("backBtnMobile")
    ?.addEventListener(
        "click",
        goBack
    );   

let tableId =
    Number(
        params.get("table")
    );

async function loadTableInfo() {
    if (!tableId) {

        return;

    }
    const cachedTables =
    await CacheService.get(
        "tables"
    );

const cachedAreas =
    await CacheService.get(
        "areas"
    );

const cachedTable =
    cachedTables.find(
        table =>
            Number(table.id) === Number(tableId)
    );

if (cachedTable) {

    const cachedArea =
        cachedAreas.find(
            area =>
                Number(area.id) ===
                Number(cachedTable.area_id)
        );

    const currentTableName =
        document.getElementById(
            "currentTableName"
        );

    if (currentTableName) {

        currentTableName.textContent =
            `${cachedArea?.name || ""} • ${cachedTable.name}`;

    }

}

    const data =
        await API.get(
            `/api/tables/${tableId}`
        );


    if (!data.success) {

        return;

    }
    const currentTableName =
    document.getElementById(
        "currentTableName"
    );

if (currentTableName) {

    currentTableName.textContent =
    `${data.table.area_name} • ${data.table.name}`;;

}

}    


const orderId =
    params.get("order");

let cartKey =
    tableId
        ? `cart_${tableId}`
        : `order_${orderId}`;

Align.Order.state.cartKey = cartKey;

Align.Order.cart.load();
let existingItems = [];    
let readyItems = [];

async function loadMenu() {

    await loadMenuData();

    if (allMenuItems.length) {

        renderCategoryFilters();

        renderFoodFilters();

        refreshMenu();

    }

}
function renderTableStrip(
    tables
) {

    const tableStrip =
        document.getElementById(
            "tableStrip"
        );

    if (!tableStrip) {

        return;

    }

    const occupiedTables =
    tables.filter(
        table => table.status !== "available"
    );

    tableStrip.innerHTML = "";

    occupiedTables.forEach(table => {

    tableStrip.innerHTML += `

<button
    onclick="openDashboardOrder(
        ${table.id},
        ${table.area_id}
    )"
    class="
        flex-shrink-0
        rounded-lg
        px-4
        py-2
        text-sm
        font-medium
        transition
        ${
            Number(table.id) === Number(tableId)
                ? "bg-slate-600 text-white"
                : "bg-amber-500 text-white hover:bg-amber-600"
        }">

    ${table.name}

</button>

`;

});

requestAnimationFrame(() => {

    updateTableStripButtons();

});

}
async function loadTableStrip() {

    const response =
        await API.get(
            "/api/tables"
        );

    if (!response.success) {

        Toast.show(
            "Unable to load tables",
            "error"
        );

        return;

    }

    renderTableStrip(
        response.tables
    );
    

}

function renderMenu(items) {

    const menu =
    window.innerWidth >= 1024
        ? document.getElementById("menuList")
        : document.getElementById("menuListMobile");   

    menu.innerHTML = "";
    let html = "";

    if (items.length === 0) {

        menu.innerHTML = `

<div class="rounded-lg border border-dashed p-8 text-center text-slate-500">

<a
            href="/admin/menu-items.html"
            class="rounded-lg bg-slate-600 px-5 py-2 font-medium text-white hover:bg-slate-800">

            Add

        </a>

</div>

`;

        return;

    }

    const normalItems =
    items.filter(
        item =>
            !item.variants ||
            item.variants.length === 0
    );

const variantItems =
    items.filter(
        item =>
            item.variants &&
            item.variants.length > 0
    );

    [...normalItems, ...variantItems].forEach(item => {

        if (
    item.variants &&
    item.variants.length === 1 &&
    !selectedVariants[item.id]
) {
    selectedVariants[item.id] =
        item.variants[0].id;
}

        const variantsHtml =
(item.variants && item.variants.length)
? `

<div class="mt-3 grid grid-cols-1 gap-2">

${item.variants.map(v => `

<div
    onclick="addItem(
        ${item.id},
        '${item.name.replace(/'/g,"\\'")}',
        ${v.price},
        ${v.id},
        '${v.name.replace(/'/g,"\\'")}'
    )"
    class="cursor-pointer rounded-lg border px-3 py-2 transition hover:bg-slate-50">

    <div class="text-sm font-medium">

        ${v.name}

    </div>

    <div class="mt-1 text-xs text-slate-500">

        ${Align.formatCurrency(v.price)}

    </div>

</div>

`).join("")}

</div>

`
: "";

html += `

<div
class="rounded-xl border border-slate-200 border-l-4
${
    item.food_type === "veg"
        ? "border-l-green-600"
    : item.food_type === "non_veg"
        ? "border-l-red-600"
    : item.food_type === "egg"
        ? "border-l-yellow-500"
    : item.food_type === "jain"
        ? "border-l-orange-500"
    : item.food_type === "vegan"
        ? "border-l-emerald-500"
    : item.food_type === "satvik"
        ? "border-l-indigo-500"
    : "border-l-slate-300"
}
bg-white p-2.5 shadow-sm transition hover:shadow-md lg:p-4">

<div class="min-w-0">

<h3 class="truncate text-sm font-semibold lg:text-base">

${item.name}

</h3>

<p class="mt-1 text-xs text-slate-500 lg:text-sm">

${item.category}

</p>

${
!item.variants || item.variants.length === 0
? `
<div
    onclick="addItem(
        ${item.id},
        '${item.name.replace(/'/g,"\\'")}',
        ${item.price}
    )"
    class="mt-2 cursor-pointer rounded-lg border px-2 py-2 transition hover:bg-slate-50">

    <div class="flex items-center justify-between">

        <div>

            <div class="text-sm font-medium">

                Price

            </div>

            <div class="text-xs text-slate-500">

                ${Align.formatCurrency(item.price)}

            </div>

        </div>

    </div>

</div>
`
: ""
}

</div>

${variantsHtml}

</div>

`;

    });
    menu.innerHTML = html;

}
function matchesMenuSearch(item, keyword) {

    if (!keyword) return true;

    keyword = keyword
        .toLowerCase()
        .trim();

    const name =
        item.name.toLowerCase();

    const category =
        item.category.toLowerCase();

    if (
        name.includes(keyword) ||
        category.includes(keyword)
    ) {
        return true;
    }

    const words =
        name.split(/\s+/);

    const initials =
        words
            .map(w => w[0])
            .join("");

    if (
        initials.startsWith(keyword)
    ) {
        return true;
    }

    const compact =
        words.join("");

    if (
        compact.includes(
            keyword.replace(/\s+/g, "")
        )
    ) {
        return true;
    }

    // pnbm
    const abbreviation =
        words
            .map(w => w.substring(0,2))
            .join("");

    if (
        abbreviation.startsWith(
            keyword.replace(/\s+/g,"")
        )
    ) {
        return true;
    }

    // paneer but
    const parts =
        keyword.split(/\s+/);

    if (
        parts.length > 1
    ) {

        return parts.every(part =>

            words.some(word =>

                word.startsWith(part)

            )

        );

    }

    return false;

}

function applyFilters() {

    const desktopSearch =
    document.getElementById("menuSearch");

const mobileSearch =
    document.getElementById("menuSearchMobile");

const keyword = (
    desktopSearch?.value ||
    mobileSearch?.value ||
    ""
)
.toLowerCase()
.trim();

    filteredMenuItems =
        allMenuItems.filter(item => {

const searchMatch =
    matchesMenuSearch(
        item,
        keyword
    );

            const categoryMatch =

                selectedCategory === "all"

                ||

                item.category_id ==
                selectedCategory;

            const foodMatch =

                selectedFoodType === "all"

                ||

                item.food_type ==
                selectedFoodType;

            return (

                searchMatch

                &&

                categoryMatch

                &&

                foodMatch

            );

        });

    renderMenu(
        filteredMenuItems
    );

}

async function initialize() {

    const takeaway =
        await API.get(
            "/api/tables/takeaway"
        );

    isTakeAway =

    takeaway.success &&

    takeaway.table &&

    Number(takeaway.table.area_id) === Number(areaId);

    await loadMenu();

await refreshCurrentTable();

await loadTableStrip();

await loadQuickItemsModal();
updateQuickItemLink();
const addQuickItemButton =
        document.getElementById(
            "addQuickItemButton"
        );

    if (addQuickItemButton) {

        addQuickItemButton.href =
            `/admin/quick-items.html?table=${tableId}&area=${areaId}`;

    }

await loadPaymentModal();
}



document
    .getElementById("sendKitchenBtn")
    .addEventListener(
        "click",
        () => sendToKitchen("kitchen")
    );
    

document
    .getElementById("printReadyBtn")
    ?.addEventListener(
        "click",
        () => sendToKitchen("print_ready")
    );

const checkoutBtn =
    document.getElementById(
        "checkoutBtn"
    );

if (checkoutBtn) {

    checkoutBtn.addEventListener(
        "click",
        () => sendToKitchen("kitchen")
    );

}

document
    .getElementById("mobilePrintReadyBtn")
    ?.addEventListener(
        "click",
        () => sendToKitchen("print_ready")
    );



initialize();

function updateQuickItemLink() {

    const addQuickItemButton =
        document.getElementById(
            "addQuickItemButton"
        );

    if (!addQuickItemButton) {

        return;

    }

    addQuickItemButton.href =
        `/admin/quick-items.html?table=${tableId}&area=${areaId}`;

}
async function loadExistingOrder() {

    if (!tableId) return;

    const active =
        await API.get(
            `/api/orders/table/${tableId}`
        );    

    if (!active.hasActiveOrder) {

    currentOrder = null;

    existingItems = [];

    renderCart();

    return;

}

    const order =
        await API.get(
            `/api/orders/${active.order.id}`
        );
    currentOrder =
    order.order;

    currentOrder = {

    ...order.order,

    ticket_id:
        active.order.ticket_id

};

    existingItems = order.items.map(item => ({

    id:
    item.is_quick_item
        ? item.quick_item_id
        : item.menu_item_id,
    quick_item_id:
    item.quick_item_id,
    is_quick_item:
    item.is_quick_item,    

    name: item.name,

    variant_name: item.variant_name,

    price: item.unit_price,

    quantity: item.quantity,

    order_item_id: item.id,

    pending_ticket_item_id:
        item.pending_ticket_item_id,

    ready_ticket_item_id:
        item.ready_ticket_item_id,

    active_ticket_item_id:
        item.active_ticket_item_id,
    note:
        item.note,    

    pending_count:
        item.pending_count || 0,

    preparing_count:
        item.preparing_count || 0,

    ready_count:
        item.ready_count || 0,

    cancelled_count:
        item.cancelled_count || 0,

    served_count:
        item.served_count || 0

}));

renderCart();

}

function addItem(
    menuItemId,
    itemName,
    unitPrice,
    variantId = null,
    variantName = null
) {

    Align.Order.cart.add({

        menu_item_id: menuItemId,

        item_name: itemName,

        variant_id: variantId,

        variant_name: variantName,

        unit_price: unitPrice

    });

    renderCart();

}


function renderCart() {

    const cart =

    Align.Order.state.cart;
    const hasNewItems = cart.length > 0;

document
    .getElementById("newCartSection")
    ?.classList.toggle(
        "hidden",
        !hasNewItems
    );

document
    .getElementById("mobileNewCartSection")
    ?.classList.toggle(
        "hidden",
        !hasNewItems
    );

    const cartDiv = document.getElementById("cart");

    if (
    existingItems.length === 0 &&
    cart.length === 0
) {

    cartDiv.innerHTML = "No Items";

    document.getElementById("total").textContent = "0";

    const mobileBar =
        document.getElementById("mobileCartBar");

    if (mobileBar) {

        mobileBar.classList.add("hidden");

    }

    document.getElementById("mobileItemCount").textContent =
        "0 Items";

    document.getElementById("mobileTotal").textContent =
        Align.formatCurrency(0);

    updateOrderAction();    

    return;

}
const serveAllContainer =
    document.getElementById(
        "serveAllContainer"
    );

const mobileServeAllContainer =
    document.getElementById(
        "mobileServeAllContainer"
    );
if (serveAllContainer) {

    serveAllContainer.innerHTML = "";

}

if (mobileServeAllContainer) {

    mobileServeAllContainer.innerHTML = "";

}

const cartSheet =
    document.getElementById(
        "cartItemsList"
    );

if (cartSheet) {

    cartSheet.innerHTML = "";

}

    let total = 0;

    cartDiv.innerHTML = "";
    

    cart.forEach(item => {

        const itemTotal =

    item.quantity *

    item.unit_price;

        total += itemTotal;

        cartDiv.innerHTML += `
<div class="mb-3 rounded-lg border p-3">

    <div class="flex items-center justify-between">

        <div>

            <h4 class="font-semibold">

                ${item.item_name}
                ${
    item.variant_name
        ? `
<p class="text-xs text-blue-600">

${item.variant_name}

</p>
`
        : ""
}

            </h4>

            <p class="text-sm text-slate-500">

                ${Align.formatCurrency(item.unit_price)} each

            </p>

        </div>

        <strong>

           ${Align.formatCurrency(itemTotal)}

        </strong>

    </div>

    <div class="mt-3 flex items-center gap-3">

    <button
        onclick="decreaseQty(
            ${item.menu_item_id || "null"},
            ${item.variant_id || "null"},
            ${item.quick_item_id || "null"}
        )"
        class="h-9 w-9 rounded bg-red-500 text-white">

        -

    </button>

    <span class="text-lg font-semibold">

        ${item.quantity}

    </span>

    <button
        onclick="increaseQty(
            ${item.menu_item_id || "null"},
            ${item.variant_id || "null"},
            ${item.quick_item_id || "null"}
        )"
        class="h-9 w-9 rounded bg-green-600 text-white">

        +

    </button>

</div>

</div>
`;
if (cartSheet) {

    cartSheet.innerHTML += `

<div class="mb-3 rounded-lg border p-3">

    <div class="flex items-center justify-between">

        <div>

            <h4 class="font-semibold">

                ${item.item_name}

                ${

                    item.variant_name

                    ? `

<p class="text-xs text-blue-600">

${item.variant_name}

</p>

`

                    : ""

                }

            </h4>

            <p class="text-sm text-slate-500">

                ${Align.formatCurrency(item.unit_price)} each

            </p>

        </div>

        <strong>

            ${Align.formatCurrency(itemTotal)}

        </strong>

    </div>

    <div class="mt-3 flex items-center gap-3">

        <button

            onclick="decreaseQty(${item.menu_item_id}, ${item.variant_id || "null"})"

            class="h-9 w-9 rounded bg-red-500 text-white">

            -

        </button>

        <span class="text-lg font-semibold">

            ${item.quantity}

        </span>

        <button

            onclick="increaseQty(${item.menu_item_id}, ${item.variant_id || "null"})"

            class="h-9 w-9 rounded bg-green-600 text-white">

            +

        </button>

    </div>

</div>

`;

}

    });    

if (existingItems.length > 0) {

    readyItems =
    existingItems.filter(
        item =>
            item.ready_count > 0
    );

    if (readyItems.length >= 2) {

        if (serveAllContainer) {

    serveAllContainer.innerHTML = `
<button
    onclick="serveAllOrderItems()"
    class="w-full rounded-lg bg-green-600 px-3 py-2 font-medium text-white hover:bg-green-700">

    ${isTakeAway ? "Hand Over All" : "Serve All"} (${readyItems.length})

</button>
`;

}

if (mobileServeAllContainer) {

    mobileServeAllContainer.innerHTML = `
<button
    onclick="serveAllOrderItems()"
    class="w-full rounded-lg bg-green-600 px-3 py-2 font-medium text-white hover:bg-green-700">

    ${isTakeAway ? "Hand Over All" : "Serve All"} (${readyItems.length})

</button>
`;

}

}

    existingItems.forEach(item => {

        const total =
            item.price * item.quantity;

        cartDiv.innerHTML += `
<div class="mb-3 rounded-lg border border-blue-200 bg-blue-50 p-3">

    <div class="flex justify-between">

        <div>

            <h4 class="font-semibold">

               ${item.name}

<small class="block text-slate-500">

${item.variant_name || ""}

</small>

            </h4>

            <p class="text-sm text-slate-500">

                Qty : ${item.quantity}

            </p>
            ${renderItemStatus(item)}

            ${canCancelItem(item) ? `
<button
    onclick="cancelOrderItem(${item.active_ticket_item_id})"
    class="mt-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700">

    Cancel Item

</button>

` : ""}
${canEditNote(item) ? `
<button
    onclick="openNoteModal(${item.active_ticket_item_id})"
    class="mt-2 ml-2 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-600">

    Note

</button>
` : ""}

${item.is_quick_item &&
  currentOrder?.status !== "ready_for_billing" ? `
<button
    onclick="removeQuickItem(${item.order_item_id})"
    class="mt-2 ml-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700">

    Remove

</button>
` : ""}

${canServeItem(item) ? `
<button
    onclick="serveOrderItem(${item.ready_ticket_item_id})"
    class="mt-2 ml-2 rounded-lg bg-green-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-green-700">

     ${isTakeAway ? " Hand Over" : " Serve"}

</button>
` : ""}

        </div>

        <strong>

           ${Align.formatCurrency(total)}

        </strong>

    </div>

</div>
`;
if (cartSheet) {

    cartSheet.innerHTML += `
<div class="mb-3 rounded-lg border border-blue-200 bg-blue-50 p-3">

    <div class="flex justify-between">

        <div>

            <h4 class="font-semibold">

                ${item.name}

                <small class="block text-slate-500">

                    ${item.variant_name || ""}

                </small>

            </h4>

            <p class="text-sm text-slate-500">

                Qty : ${item.quantity}

            </p>

            ${renderItemStatus(item)}

            ${canCancelItem(item) ? `
<button
    onclick="cancelOrderItem(${item.active_ticket_item_id})"
    class="mt-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white">

    Cancel Item

</button>

` : ""}
${canEditNote(item) ? `
<button
    onclick="openNoteModal(${item.active_ticket_item_id})"
    class="mt-2 ml-2 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-600">

    Note

</button>
` : ""}
${item.is_quick_item &&
  currentOrder?.status !== "ready_for_billing" ? `
<button
    onclick="removeQuickItem(${item.order_item_id})"
    class="mt-2 ml-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-red-700">

    Remove

</button>
` : ""}

            ${canServeItem(item) ? `
<button
    onclick="serveOrderItem(${item.ready_ticket_item_id})"
    class="mt-2 ml-2 rounded-lg bg-green-600 px-3 py-1.5 text-xs font-medium text-white">

    ${isTakeAway ? " Handed Over" : " Served"}

</button>
` : ""}

        </div>

        <strong>

            ${Align.formatCurrency(total)}

        </strong>

    </div>

</div>
`;

}

    });


}    

    document.getElementById("total").textContent =
    Align.formatCurrency(
        Align.Order.cart.total()
    );
        sessionStorage.setItem(
    cartKey,
    JSON.stringify(cart)
);
const totalItems =
    cart.reduce(

        (sum, item) =>

            sum + item.quantity,

        0

    );

const mobileBar =
    document.getElementById(
        "mobileCartBar"
    );

if (mobileBar) {

    if (
        totalItems === 0 &&
        existingItems.length === 0
    ) {

        mobileBar.classList.add(
            "hidden"
        );

    } else {

        mobileBar.classList.remove(
            "hidden"
        );

    }

}

document.getElementById("mobileItemCount").textContent =
    `${totalItems} Item${totalItems === 1 ? "" : "s"}`;

document.getElementById("mobileTotal").textContent =
    Align.formatCurrency(
        Align.Order.cart.total()
    );
updateOrderAction();
const hasMenuItems =
    Align.Order.state.cart.some(
        item => !item.is_quick_item
    );

const hasQuickItems =
    Align.Order.state.cart.some(
        item => item.is_quick_item
    );

const onlyQuickItems =
    hasQuickItems &&
    !hasMenuItems;

const buttonText =
    onlyQuickItems
        ? "Save"
        : "Send To Kitchen";

const sendButton =
    document.getElementById(
        "sendKitchenBtn"
    );

if (sendButton) {

    sendButton.textContent =
        buttonText;

}

const checkoutButton =
    document.getElementById(
        "checkoutBtn"
    );

if (checkoutButton) {

    checkoutButton.textContent =
        buttonText;

}    

}
function updateOrderAction() {

    const boxes = [

        document.getElementById(
            "orderAction"
        ),

        document.getElementById(
            "mobileOrderAction"
        )

    ].filter(Boolean);

    if (
        boxes.length === 0 ||
        !currentOrder
    ) {

        return;

    }

    boxes.forEach(box => {

        box.classList.add(
            "hidden"
        );

        box.innerHTML = "";

    });

    const quickItemsRemoved =
    existingItems.length === 0 &&
    Align.Order.state.cart.length === 0 &&
    currentOrder &&
    currentOrder.status === "sent_to_kitchen";

    if (
    existingItems.length === 0 &&
    !quickItemsRemoved
) {

    return;

}

    const hasUnsavedItems =
    Align.Order.state.cart.length > 0;

if (hasUnsavedItems) {

    return;

}
    

    const pending =
        existingItems.some(
            i => i.pending_count > 0
        );

    const preparing =
        existingItems.some(
            i => i.preparing_count > 0
        );

    const ready =
        existingItems.some(
            i => i.ready_count > 0
        );

    const served =
        existingItems.some(
            i => i.served_count > 0
        );

    const cancelled =
        existingItems.some(
            i => i.cancelled_count > 0
        ); 
    const hasQuickItems =
    existingItems.some(
        i => i.is_quick_item
    );    

    let html = "";
    let handler = null;

    // Print Bill

if (
    currentOrder.status ===
    "ready_for_billing"
) {

    html = `
<button
    class="action-btn w-full rounded-xl bg-green-600 py-3 font-semibold text-white">

    Pay

</button>
`;

    handler = () =>
{
    
    openPaymentModal(currentOrder);
};

}


else if (

    !pending &&
    !preparing &&
    !ready &&
    served

) {

    html = `
<button
    class="action-btn w-full rounded-xl bg-green-600 py-3 font-semibold text-white">

    Send To Billing

</button>
`;

    handler = () =>
        sendToBilling(currentOrder.id);

}
else if (

    !pending &&
    !preparing &&
    !ready &&
    !served &&
    hasQuickItems

) {

    html = `
<button
    class="action-btn w-full rounded-xl bg-green-600 py-3 font-semibold text-white">

    Send To Billing

</button>
`;

    handler = () =>
        sendToBilling(
            currentOrder.id
        );

}


    // Close Order

    else if (

    (
        !pending &&
        !preparing &&
        !ready &&
        !served &&
        cancelled
    ) ||
    quickItemsRemoved

) {

        html = `
<button
    class="action-btn w-full rounded-xl bg-red-600 py-3 font-semibold text-white">

    Close Order

</button>
`;

       if (quickItemsRemoved) {

    handler = () =>
        closeOrder(
            currentOrder.id
        );

}
else {

    handler = () =>
        closeCancelledOrder(
            currentOrder.ticket_id
        );

}

    }

    if (!html) {

        return;

    }

    boxes.forEach(box => {

        box.classList.remove(
            "hidden"
        );

        box.innerHTML = html;

        if (handler) {

            box.querySelector(
                ".action-btn"
            ).onclick = handler;

        }

    });

}



function increaseQty(
    menuItemId,
    variantId = null,
    quickItemId = null
) {

    Align.Order.cart.increase(

        menuItemId,

        variantId,

        quickItemId

    );

    renderCart();

}

function decreaseQty(
    menuItemId,
    variantId = null,
    quickItemId = null
) {

    Align.Order.cart.decrease(

        menuItemId,

        variantId,

        quickItemId

    );

    renderCart();

}
function openCart() {

    document
        .getElementById("cartSheet")
        .classList.remove("hidden");

    renderCart();

}

function closeCart() {

    document
        .getElementById("cartSheet")
        .classList.add("hidden");

}
async function sendToKitchen(
    mode = "kitchen"
) {

    if (Align.Order.state.cart.length === 0) {

        Toast.show(
            "Cart is empty",
            "error"
        );

        return;

    }
    const hasMenuItems =
    Align.Order.state.cart.some(
        item => !item.is_quick_item
    );

const hasQuickItems =
    Align.Order.state.cart.some(
        item => item.is_quick_item
    );

const onlyQuickItems =
    hasQuickItems &&
    !hasMenuItems;

    const sendButton =
        document.getElementById(
            "sendKitchenBtn"
        );

    const cartButton =
        document.getElementById(
            "checkoutBtn"
        );

    if (sendButton) {

    sendButton.disabled = true;

    sendButton.textContent =
    onlyQuickItems
        ? "Saving..."
        : "Sending...";

}

if (cartButton) {

    cartButton.disabled = true;

    cartButton.textContent =
    onlyQuickItems
        ? "Saving..."
        : "Sending...";

}

    try {

        const payload = {

    table_id: Number(tableId),

    mode,

    items: Align.Order.state.cart.map(item => ({

        menu_item_id:
            item.menu_item_id,

        quick_item_id:
            item.quick_item_id,

        is_quick_item:
            item.is_quick_item,

        variant_id:
            item.variant_id,

        quantity:
            item.quantity,

        notes:
            item.notes || ""

    }))

};

        const data =
            await API.post(
                "/api/orders/checkout",
                payload
            );

        if (!data.success) {

            Toast.show(
                data.message,
                "error"
            );

            return;

        }

        Align.Order.cart.clear();

        if (typeof updateCartSummary === "function") {

    updateCartSummary();

}

        if (typeof closeCart === "function") {

    closeCart();

}

        if (typeof loadCurrentOrder === "function") {

    await loadCurrentOrder();

}

        if (typeof loadTable === "function") {

    await loadTable();
    


}

if (
    mode === "print_ready" &&
    data.ticketId
) {

    window.open(
        `/admin/kot-print.html?ticket=${data.ticketId}`,
        "_blank"
    );

}
        Toast.show(
    onlyQuickItems
        ? "Quick items saved"
        : "Order sent successfully",
    "success"
);
        await refreshCurrentTable();

await loadTableStrip();

await loadMenu();

    }
    catch (err) {

        Toast.show(
            err.message,
            "error"
        );

    }
    finally {

       if (sendButton) {

    sendButton.disabled = false;

    sendButton.textContent =
    onlyQuickItems
        ? "Save"
        : "Send To Kitchen";

}

if (cartButton) {

    cartButton.disabled = false;

    cartButton.textContent =
    onlyQuickItems
        ? "Save"
        : "Send To Kitchen";

}

    }

}

function renderCategoryFilters() {

    const itemsForCategories =

        selectedFoodType === "all"

            ? allMenuItems

            : allMenuItems.filter(

                item => item.food_type === selectedFoodType

            );

    const categories = [

        {
            id: "all",
            name: "All"
        },

        ...new Map(

            itemsForCategories.map(item => [

                item.category_id,

                {
                    id: item.category_id,
                    name: item.category
                }

            ])

        ).values()

    ];

    const containers = [

        document.getElementById("categoryFilters"),
        document.getElementById("categoryFiltersDesktop")

    ].filter(Boolean);

    containers.forEach(container => {

        container.innerHTML = "";

        categories.forEach(cat => {
            const sampleItem = itemsForCategories.find(
    item => item.category_id == cat.id
);

let borderColor = "border-l-blue-600";

if (selectedFoodType !== "all") {

    borderColor =
        sampleItem?.food_type === "veg"
            ? "border-l-green-600"
        : sampleItem?.food_type === "non_veg"
            ? "border-l-red-600"
        : sampleItem?.food_type === "egg"
            ? "border-l-yellow-500"
        : sampleItem?.food_type === "jain"
            ? "border-l-orange-500"
        : sampleItem?.food_type === "vegan"
            ? "border-l-emerald-500"
        : sampleItem?.food_type === "satvik"
            ? "border-l-indigo-500"
        : "border-l-blue-600";

}

            container.innerHTML += `

<button

onclick="selectCategory('${cat.id}')"

class="category-chip flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition hover:bg-slate-50"

data-id="${cat.id}"
data-color="${borderColor}">


<span>${cat.name}</span>

<span
class="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">

${
    cat.id === "all"
        ? itemsForCategories.length
        : itemsForCategories.filter(
              item => item.category_id == cat.id
          ).length
}

</span>

</button>

`;

        });

    });

    const exists = categories.some(

        c => String(c.id) === String(selectedCategory)

    );

    if (!exists) {

        selectedCategory = "all";

    }

    updateCategorySelection();

}
function selectCategory(id) {

    selectedCategory = id;

    updateCategorySelection();

    applyFilters();

}
function updateCategorySelection() {

    document

        .querySelectorAll(
            ".category-chip"
        )

        .forEach(btn => {

            if (

                btn.dataset.id ==
                selectedCategory

            ) {

                btn.className =
`category-chip flex items-center justify-between rounded-lg border border-slate-200 border-l-4 ${btn.dataset.color} bg-slate-100 px-3 py-2 text-sm font-medium`;

            } else {

                btn.className =
"category-chip flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition hover:bg-slate-50";

            }

        });

}

function renderFoodFilters() {
    

    const container =
        document.getElementById(
            "foodFilters"
        );
    const availableFoodTypes =
    [
        ...new Set(
            allMenuItems.map(
                item => item.food_type
            )
        )
    ];

if (availableFoodTypes.length <= 1) {

    container.classList.add(
        "hidden"
    );

    selectedFoodType = "all";

    return;

}    

    container.innerHTML = "";

    const icons = {

    veg: "🟢",

    egg: "🥚",

    non_veg: "🔴",

    vegan: "🌱",

    jain: "🟡",

    satvik: "🪷"

};

    const foodTypes = [

        {

            id: "all",

            name: "All"

        },

        ...new Map(

            allMenuItems.map(item => [

                item.food_type,

                {

                    id: item.food_type,

                    name:

                        `${icons[item.food_type] || "🍽️"} ` +

                        item.food_type

                            .replace(/_/g, " ")

                            .replace(/\b\w/g, c => c.toUpperCase())

                }

            ])

        ).values()

    ];

    foodTypes.forEach(type => {

        container.innerHTML += `

<button

onclick="selectFoodType('${type.id}')"

class="food-chip rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition hover:bg-slate-50"

data-id="${type.id}">

${type.name}

</button>

`;

    });

    updateFoodSelection();

}
function selectFoodType(id) {

    selectedFoodType = id;

    selectedCategory = "all";

    updateFoodSelection();

    renderCategoryFilters();

    applyFilters();

}
function updateFoodSelection() {

    document

        .querySelectorAll(".food-chip")

        .forEach(btn => {

            if (

                btn.dataset.id ==
                selectedFoodType

            ) {

                btn.className =
"food-chip rounded-lg border border-slate-200 bg-slate-600 px-3 py-2 text-sm font-medium text-white";

            }

            else {

                btn.className =
"food-chip rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition hover:bg-slate-50";

            }

        });

}
const desktopSearch =
    document.getElementById("menuSearch");

const mobileSearch =
    document.getElementById("menuSearchMobile");
document
    .getElementById("mobileViewCartBtn")
    ?.addEventListener(
        "click",
        openCart
    );    

desktopSearch?.addEventListener("input", () => {

    if (mobileSearch) {

        mobileSearch.value =
            desktopSearch.value;

    }

    applyFilters();

});

mobileSearch?.addEventListener("input", () => {

    if (desktopSearch) {

        desktopSearch.value =
            mobileSearch.value;

    }
    


    applyFilters();
    

});

async function printBill(orderId)
{
    window.location.href =
        `/admin/billing.html?order=${orderId}`;
}
async function removeQuickItem(
    orderItemId
) {

    try {

        const data =
            await API.delete(
                `/api/orders/quick-item/${orderItemId}`
            );
            

        if (!data.success) {

            Toast.show(
                data.message,
                "error"
            );

            return;

        }

        Toast.show(
            "Quick item removed",
            "success"
        );

        await loadExistingOrder();

        renderCart();

    }
    catch (err) {

        Toast.show(
            err.message,
            "error"
        );

    }

}
async function closeOrder(
    orderId
) {

    try {

        const data =
            await API.patch(
                `/api/orders/${orderId}/close`
            );

        if (!data.success) {

            Toast.show(
                data.message,
                "error"
            );

            return;

        }

        Toast.show(
            "Order Closed",
            "success"
        );

        window.location.href =
            `/admin/area.html?id=${areaId}`;

    }
    catch (err) {

        Toast.show(
            err.message,
            "error"
        );

    }

}

async function sendToBilling(orderId) {

    try {

        const data =
            await API.patch(
                `/api/orders/${orderId}/send-to-billing`
            );

        if (!data.success) {

            Toast.show(
                data.message,
                "error"
            );

            return;

        }

        Toast.show(
            "Sent To Billing",
            "success"
        );

        await loadExistingOrder();
        await loadTableStrip();

        renderCart();

    }

    catch (err) {

        Toast.show(
            err.message,
            "error"
        );

    }

}
async function closeCancelledOrder(ticketId) {
    

    const data =
        await API.patch(
            `/api/kitchen/${ticketId}/close-cancelled`
        );

    if (!data.success) {

        Toast.show(
            data.message,
            "error"
        );

        return;

    }

    Toast.show(
        "Order Closed",
        "success"
    );

    window.location.href =
        `/admin/area.html?id=${areaId}`;

}

async function openDashboardOrder(
    newTableId,
    newAreaId
) {

    await switchTable(
        newTableId,
        newAreaId
    );

}

async function refreshCurrentTable() {

    cartKey =
        tableId
            ? `cart_${tableId}`
            : `order_${orderId}`;

    Align.Order.state.cartKey =
        cartKey;

    Align.Order.state.cart = [];

    Align.Order.cart.load();

    await loadTableInfo();

    await loadExistingOrder();

    renderCart();

}
function refreshMenu() {

    applyFilters();

}
async function loadMenuData() {

    const cachedMenuItems =
        await CacheService.get(
            "menuItems"
        );

    if (cachedMenuItems.length) {

        allMenuItems =
            cachedMenuItems
                .filter(
                    item =>
                        item.is_available == 1
                )
                .sort(
                    (a, b) =>
                        a.name.localeCompare(
                            b.name,
                            undefined,
                            {
                                sensitivity:
                                    "base"
                            }
                        )
                );

        renderCategoryFilters();

        renderFoodFilters();

        refreshMenu();

    }

    const data =
        await API.get(
            "/api/menu/items/all"
        );

    if (!data.success) {

        if (!cachedMenuItems.length) {

            Toast.show(
                data.message,
                "error"
            );

        }

        return false;

    }

    const menuSync =
        await CacheService.sync(
            "menuItems",
            data.items
        );

    if (

        !cachedMenuItems.length ||
        menuSync.changed

    ) {

        allMenuItems =
            data.items
                .filter(
                    item =>
                        item.is_available == 1
                )
                .sort(
                    (a, b) =>
                        a.name.localeCompare(
                            b.name,
                            undefined,
                            {
                                sensitivity:
                                    "base"
                            }
                        )
                );

        renderCategoryFilters();

        renderFoodFilters();

        refreshMenu();

    }

    return true;

}
async function switchTable(
    newTableId,
    newAreaId
) {

    tableId =
        Number(newTableId);

    areaId =
        Number(newAreaId);

    await refreshCurrentTable();

    await loadTableStrip();

    history.pushState(
        {},
        "",
        `/admin/order.html?table=${tableId}&area=${areaId}`
    );
updateQuickItemLink();     

}

const tableStrip =
    document.getElementById(
        "tableStrip"
    );

const leftButton =
    document.getElementById(
        "tableStripLeft"
    );

const rightButton =
    document.getElementById(
        "tableStripRight"
    );

function updateTableStripButtons() {

    const maxScroll =
        tableStrip.scrollWidth -
        tableStrip.clientWidth;

    if (maxScroll <= 0) {

        leftButton.classList.add(
            "hidden"
        );

        rightButton.classList.add(
            "hidden"
        );

        return;

    }

    leftButton.classList.toggle(
        "hidden",
        tableStrip.scrollLeft <= 5
    );

    rightButton.classList.toggle(
        "hidden",
        tableStrip.scrollLeft >= maxScroll - 5
    );

}

leftButton.addEventListener(
    "click",
    () => {

        tableStrip.scrollBy({

            left: -250,

            behavior: "smooth"

        });

    }
);

rightButton.addEventListener(
    "click",
    () => {

        tableStrip.scrollBy({

            left: 250,

            behavior: "smooth"

        });

    }
);

tableStrip.addEventListener(
    "scroll",
    updateTableStripButtons
);

window.addEventListener(
    "resize",
    updateTableStripButtons
);
document
    .getElementById(
        "quickItemsBtn"
    )
    .addEventListener(
        "click",
        openQuickItemsModal
    );
   
function openNoteModal(
    ticketItemId
) {

    const item =
        existingItems.find(
            item =>
                item.active_ticket_item_id ===
                ticketItemId
        );

    currentNoteItem =
        ticketItemId;

    Modal.open(

        "Kitchen Note",

        `
<textarea
    id="kitchenNote"
    class="w-full rounded-lg border p-3"
    rows="5"
    maxlength="300"
    placeholder="Enter kitchen note...">${item?.note || ""}</textarea>
`,

        saveItemNote,

        {

            buttonText:
                "Save Note",

            loadingText:
                "Saving..."

        }

    );

}

async function saveItemNote() {

    const note =
        document.getElementById(
            "kitchenNote"
        ).value;

    try {

        const data =
            await API.patch(

                `/api/kitchen/items/${currentNoteItem}/note`,

                {
                    note
                }

            );

        if (!data.success) {

            Toast.show(
                data.message,
                "error"
            );

            return;

        }

        Modal.close();

        Toast.show(
            "Kitchen note updated",
            "success"
        );

        await loadExistingOrder();

        renderCart();

    }

    catch (err) {

        Toast.show(
            err.message,
            "error"
        );

    }

}
function canEditNote(item) {

    return (
        item.pending_count > 0 ||
        item.preparing_count > 0
    );

}
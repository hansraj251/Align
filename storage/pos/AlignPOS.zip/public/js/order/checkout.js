window.Checkout = {

    async send() {

    }

};
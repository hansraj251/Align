Auth.redirectIfLoggedIn();

document
    .getElementById("loginBtn")
    .addEventListener("click", login);
document.addEventListener(
    "keydown",
    (event) => {

        if (event.key !== "Enter") {

            return;

        }

        event.preventDefault();

        document
            .getElementById("loginBtn")
            .click();

    }
);

async function login() {

    let fcmToken = "";

if (
    window.Android &&
    typeof Android.getFcmToken === "function"
) {

    fcmToken =
        Android.getFcmToken();

}

    const loginId = document
        .getElementById("loginId")
        .value
        .trim();

    const password = document
        .getElementById("password")
        .value;

    const result = document.getElementById("result");

    result.textContent = "";

    // Try Super Admin Login first
if (!loginId || !password) {

        result.textContent =
            "Username/Email and Password are required.";

        return;

    }  
    
    try {


    let data;

    if (loginId.includes("@")) {

        // Owner / Admin Login

        data = await API.post(
            "/api/auth/login",
            {
                email: loginId,
                password
            }
        );
        

        if (!data.success) {

            result.textContent = data.message;

            return;

        }

        localStorage.setItem(
            "token",
            data.token
        );
        const payload = JSON.parse(
    atob(data.token.split(".")[1])
);

localStorage.setItem(
    "restaurant_id",
    payload.restaurantId
);

        window.location.href =
            "/admin/dashboard.html";

    } else {

        // Staff Login

        data = await API.post(
    "/api/staff-auth/login",
    {
        username: loginId,
        password,
        fcmToken
    }
);
        

        if (!data.success) {

            result.textContent = data.message;

            return;

        }

        localStorage.setItem(
            "staffToken",
            data.token
        );


localStorage.setItem(
    "restaurant_id",
    data.restaurant_id
);


localStorage.setItem(
    "staff",
    JSON.stringify({
        ...data.staff,
        restaurant_id: data.restaurant_id,
        restaurant_name: data.restaurant_name
    })
);

        localStorage.setItem(
            "restaurantName",
            data.restaurant_name || ""
        );
        

        switch (data.staff.role) {

            case "owner":
            case "manager":
                window.location.href = "/admin/dashboard.html";
                break;

            case "waiter":
            case "device":

    window.location.href =
        "/waiter/dashboard.html";

    break;

            case "kitchen":
                window.location.href = "/admin/kitchen.html";
                break;

            case "cashier":
                window.location.href = "/admin/billing.html";
                break;

            default:
                result.textContent = "Unknown role";
        }
        

    }

} catch (err) {

        console.error(err);

        result.textContent =
            "Unable to connect to server.";

    }

}

const togglePassword =
    document.getElementById(
        "togglePassword"
    );

const passwordInput =
    document.getElementById(
        "password"
    );

togglePassword.addEventListener(
    "click",
    () => {

        passwordInput.type =
            passwordInput.type ===
            "password"
                ? "text"
                : "password";

    }
);
const db = require("../db");

exports.createTicket = async (
    orderId,
    mode = "kitchen"
) => {

    const result =

        await db.runAsync(

            `
INSERT INTO kitchen_tickets
(
    order_id,
    mode
)
VALUES (?, ?)

            `,

            [
    orderId,
    mode
]

        );

    return result.lastID;

};

exports.updateTicketNumber = async (
    ticketId,
    ticketNumber
) => {

    await db.runAsync(
        `
        UPDATE kitchen_tickets
        SET ticket_number = ?
        WHERE id = ?
        `,
        [
            ticketNumber,
            ticketId
        ]
    );

    return ticketNumber;

};

exports.createTicketItem = async (
    ticketId,
    orderItemId,
    menuItemId,
    itemName,
    variantName,
    unitPrice,
    quantity
) => {

    await db.runAsync(
        `
       INSERT INTO kitchen_ticket_items
(
    ticket_id,
    order_item_id,
    menu_item_id,
    item_name,
    variant_name,
    unit_price,
    quantity,
    status
)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [

    ticketId,

    orderItemId,

    menuItemId,

    itemName,

    variantName,

    unitPrice,

    quantity,

    "pending"

]
    );

};

exports.getActiveTickets = async (
    restaurantId
) => {

    return await db.allAsync(
        `
        SELECT

    kt.id,

    kt.ticket_number,

    kt.status,

    kt.created_at,

    o.order_number,

    t.area_id,

    o.area_name,

    o.table_name,

    o.total

        FROM kitchen_tickets kt

JOIN orders o
    ON o.id = kt.order_id

LEFT JOIN tables t
    ON t.id = o.table_id

        WHERE

            o.restaurant_id = ?

             AND kt.mode = 'kitchen'

            AND kt.status IN
            (
                'new',
                'preparing',
                'ready'
            )

        ORDER BY

            kt.created_at ASC
        `,
        [
            restaurantId
        ]
    );

};



exports.getTicketItems = async (
    ticketId
) => {

    return await db.allAsync(
        `
        SELECT

            kti.id,

            kti.ticket_id,

            kti.order_item_id,

            kti.menu_item_id,

            kti.item_name,

            kti.variant_name,

            kti.quantity,

            kti.unit_price,

            kti.status,

            kti.note,

            mi.food_type,

            mc.name AS category_name

        FROM kitchen_ticket_items kti

        LEFT JOIN menu_items mi
            ON mi.id = kti.menu_item_id

        LEFT JOIN menu_categories mc
            ON mc.id = mi.category_id

        WHERE kti.ticket_id = ?

        ORDER BY kti.id
        `,
        [
            ticketId
        ]
    );

};

exports.updateTicketStatus = async (
    ticketId,
    status
) => {

    let query = `
        UPDATE kitchen_tickets
        SET
            status = ?
    `;

    const params = [
        status
    ];

    if (status === "preparing") {

        query += `,
            started_at = CURRENT_TIMESTAMP
        `;

    }

    if (status === "ready") {

        query += `,
            ready_at = CURRENT_TIMESTAMP
        `;

    }

    query += `
        WHERE id = ?
    `;

    params.push(ticketId);

    await db.runAsync(
        query,
        params
    );

};
exports.getTicketById = async (
    ticketId
) => {

    return await db.getAsync(
        `
        SELECT

            kt.id,

            kt.order_id,

            kt.ticket_number,

            kt.status,

            kt.mode,

            o.restaurant_id,

            o.created_by_staff_id,

            o.table_id,

            t.area_id,

            o.table_name,

            o.area_name

        FROM kitchen_tickets kt

        JOIN orders o
            ON o.id = kt.order_id

        LEFT JOIN tables t
            ON t.id = o.table_id    

        WHERE kt.id = ?
        `,
        [
            ticketId
        ]
    );

};
exports.getActiveTicketsByOrder = async (
    orderId
) => {

    return await db.allAsync(
        `
        SELECT
            id
        FROM kitchen_tickets
        WHERE
            order_id = ?
            AND status IN (
    'new',
    'preparing',
    'ready',
    'served'
)
        ORDER BY id
        `,
        [
            orderId
        ]
    );

};
exports.updateOrderItemsStatus = async (
    orderId,
    status
) => {

    await db.runAsync(
        `
        UPDATE order_items
        SET
            status = ?
        WHERE
            order_id = ?
        `,
        [
            status,
            orderId
        ]
    );

};

exports.getActiveTicketCountByOrder = async (
    orderId
) => {

    const row =
        await db.getAsync(
            `
            SELECT
                COUNT(*) AS total
            FROM kitchen_tickets
            WHERE
                order_id = ?
                AND status IN (
                    'new',
                    'preparing',
                    'ready'
                )
            `,
            [
                orderId
            ]
        );

    return row.total;

};
exports.getLastKotNumberForToday = async (restaurantId) => {

    const today = new Date();

    const date =
        `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, "0")}${String(today.getDate()).padStart(2, "0")}`;

    return await db.getAsync(
        `
        SELECT
    kt.ticket_number
FROM kitchen_tickets kt
INNER JOIN orders o
    ON o.id = kt.order_id
WHERE
    o.restaurant_id = ?
    AND kt.ticket_number LIKE ?
ORDER BY
    kt.id DESC
LIMIT 1;
        `,
        [
    restaurantId,
    `KOT-${date}-%`
]
    );

};
exports.updateTicketStatusByOrder = async (
    orderId,
    status
) => {

    await db.runAsync(
        `
        UPDATE kitchen_tickets
        SET
            status = ?
        WHERE
            order_id = ?
            AND status != 'served'
        `,
        [
            status,
            orderId
        ]
    );

};

exports.getTicketItem = async (
    ticketItemId
) => {

    return await db.getAsync(
        `
        SELECT

            kti.id,

            kti.ticket_id,

            kti.item_name,

            kti.status,

            kt.ticket_number,

            kt.order_id,

            o.restaurant_id,

            o.created_by_staff_id,

            o.table_name,

            o.area_name


        FROM kitchen_ticket_items kti

        JOIN kitchen_tickets kt
            ON kt.id = kti.ticket_id

        JOIN orders o
            ON o.id = kt.order_id

        WHERE kti.id = ?
        `,
        [ticketItemId]
    );

};

exports.getPendingTicketItems = async (
    ticketId
) => {

    const row =
        await db.getAsync(
            `
            SELECT
    COUNT(*) AS total
FROM kitchen_ticket_items
WHERE
    ticket_id = ?
    AND status IN (
        'pending',
        'preparing'
    )
            `,
            [ticketId]
        );

    return row.total;

};
exports.getReadyTicketItems = async (
    ticketId
) => {

    const row =
        await db.getAsync(

            `
SELECT
    COUNT(*) AS total
FROM kitchen_ticket_items
WHERE
    ticket_id = ?
    AND status = 'ready'
`,

            [ticketId]

        );

    return row.total;

};
exports.updateTicketItemsStatus = async (
    ticketId,
    status
) => {

    let query = `
        UPDATE kitchen_ticket_items
        SET
            status = ?
    `;

    const params = [status];

    if (status === "preparing") {

        query += `,
            started_at = CURRENT_TIMESTAMP`;

    }

    if (status === "ready") {

        query += `,
            ready_at = CURRENT_TIMESTAMP`;

    }
    if (status === "served") {

    query += `,
        served_at = CURRENT_TIMESTAMP`;

}

    query += `
    WHERE
        ticket_id = ?
`;

params.push(ticketId);

if (status === "preparing") {

    query += `
        AND status = 'pending'
    `;

}

if (status === "ready") {

    query += `
        AND status = 'preparing'
    `;

}
if (status === "served") {

    query += `

        AND status = 'ready'

    `;

}

    await db.runAsync(
        query,
        params
    );

};
exports.updateTicketItemStatus = async (
    ticketItemId,
    status
) => {

    let query = `
        UPDATE kitchen_ticket_items
        SET
            status = ?
    `;

    const params = [
        status
    ];

    if (status === "preparing") {

        query += `,
            started_at = CURRENT_TIMESTAMP
        `;

    }

    if (status === "ready") {

        query += `,
            ready_at = CURRENT_TIMESTAMP
        `;

    }

    if (status === "served") {

        query += `,
            served_at = CURRENT_TIMESTAMP
        `;

    }

    query += `
        WHERE id = ?
    `;

    params.push(ticketItemId);

    await db.runAsync(
        query,
        params
    );
    

};
exports.updateTicketItemsStatusByIds = async (
    ticketItemIds,
    status
) => {

    if (!ticketItemIds.length) {

        return;

    }

    let query = `
        UPDATE kitchen_ticket_items
        SET
            status = ?
    `;

    const params = [
        status
    ];

    if (status === "served") {

        query += `,
            served_at = CURRENT_TIMESTAMP`;

    }

    query += `
        WHERE id IN (${ticketItemIds.map(() => "?").join(",")})
    `;

    params.push(
        ...ticketItemIds
    );

    if (status === "served") {

        query += `
            AND status = 'ready'
        `;

    }

    await db.runAsync(
        query,
        params
    );

};
exports.cancelTicketItem = async (
    ticketItemId
) => {

    await db.runAsync(
        `
        UPDATE kitchen_ticket_items
        SET
            status = 'cancelled'
        WHERE
            id = ?
            AND status = 'pending'
        `,
        [ticketItemId]
    );

};
exports.adminCancelTicketItem = async (
    ticketItemId
) => {

    const result =
        await db.runAsync(
            `
            UPDATE kitchen_ticket_items
            SET
                status = 'cancelled'
            WHERE
                id = ?
                AND status IN (
                    'pending',
                    'preparing',
                    'ready'
                )
            `,
            [ticketItemId]
        );

    return result.changes;

};
exports.closeTicket = async (
    ticketId
) => {

    await db.runAsync(
        `
        UPDATE kitchen_tickets
        SET
            status = 'closed'
        WHERE
            id = ?
        `,
        [ticketId]
    );

};
exports.closeAllTicketsByOrder = async (
    orderId
) => {

    await db.runAsync(
        `
        UPDATE kitchen_tickets
        SET status = 'closed'
        WHERE
            order_id = ?
            AND status IN (
                'new',
                'preparing',
                'ready'
            )
        `,
        [orderId]
    );

};
exports.markTicketReadyDirect = async (
    ticketId
) => {

    await db.runAsync(
        `
        UPDATE kitchen_tickets
        SET
            status = 'ready',
            ready_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [
            ticketId
        ]
    );

    await db.runAsync(
        `
        UPDATE kitchen_ticket_items
        SET
            status = 'ready',
            ready_at = CURRENT_TIMESTAMP
        WHERE ticket_id = ?
        `,
        [
            ticketId
        ]
    );

};

exports.getTicketPrintData = async (
    ticketId
) => {

    return await db.getAsync(
        `
        SELECT
    kt.id AS ticket_id,
    kt.ticket_number,
    kt.status,
    kt.created_at,
    o.id AS order_id,
    t.name AS table_name,
    a.name AS area_name

        FROM kitchen_tickets kt

        INNER JOIN orders o
            ON o.id = kt.order_id

        INNER JOIN tables t
            ON t.id = o.table_id

        INNER JOIN dining_areas a
            ON a.id = t.area_id

        WHERE kt.id = ?
        `,
        [
            ticketId
        ]
    );

};

exports.getTicketPrintItems = async (
    ticketId
) => {

    return await db.allAsync(
        `
        SELECT

            item_name AS name,

            variant_name,

            quantity,
            note

        FROM kitchen_ticket_items

        WHERE ticket_id = ?

        ORDER BY id
        `,
        [
            ticketId
        ]
    );

};
exports.updateTicketItemNote = async (
    ticketItemId,
    note
) => {

    await db.runAsync(
        `
        UPDATE kitchen_ticket_items
        SET
            note = ?
        WHERE
            id = ?
            AND status IN (
                'pending',
                'preparing'
            )
        `,
        [
            note,
            ticketItemId
        ]
    );

};
exports.getFoodTypes = async (
    restaurantId
) => {

    return await db.allAsync(
        `
        SELECT DISTINCT
            food_type
        FROM menu_items
        WHERE
    restaurant_id = ?
    AND status = 1
    AND is_available = 1
    AND food_type IS NOT NULL
    AND TRIM(food_type) != ''
        ORDER BY
            food_type
        `,
        [
            restaurantId
        ]
    );

};
exports.getCategories = async (
    restaurantId
) => {

    return await db.allAsync(
        `
        SELECT
    id,
    name
FROM menu_categories
WHERE
    restaurant_id = ?
ORDER BY
    name;
        `,
        [
            restaurantId
        ]
    );

};
const db = require("../db");

exports.getRestaurant = async (restaurantId) => {

    return await db.getAsync(
        `
        SELECT

            id,
            name,
            owner_name,
            mobile,
            email,
            gst_number,
            fssai_number,
            address,
            city,
            state,
            pincode,
            logo

        FROM restaurants
        WHERE id = ?
        `,
        [restaurantId]
    );

};
exports.getById = async (restaurantId) => {

    return await db.getAsync(
        `
        SELECT *
        FROM restaurants
        WHERE id = ?
        `,
        [restaurantId]
    );

};

exports.updateRestaurant = async (
    restaurantId,
    restaurant
) => {

    await db.runAsync(
        `
        UPDATE restaurants
        SET

            name = ?,
            owner_name = ?,
            mobile = ?,
            gst_number = ?,
            fssai_number = ?,
            address = ?,
            city = ?,
            state = ?,
            pincode = ?,
            updated_at = CURRENT_TIMESTAMP

        WHERE id = ?
        `,
        [

            restaurant.name,
            restaurant.owner_name,
            restaurant.mobile,
            restaurant.gst_number,
            restaurant.fssai_number,
            restaurant.address,
            restaurant.city,
            restaurant.state,
            restaurant.pincode,
            restaurantId

        ]
    );

};
exports.getRestaurantForReceipt = async (restaurantId) => {

    return await db.getAsync(
        `
        SELECT
            name,
            logo,
            mobile,
            email,
            gst_number,
            address,
            city,
            state,
            pincode
        FROM restaurants
        WHERE id = ?
        `,
        [restaurantId]
    );

};
exports.updateLogo = async (
    restaurantId,
    logo
) => {

    await db.runAsync(
        `
        UPDATE restaurants
        SET

            logo = ?,
            updated_at = CURRENT_TIMESTAMP

        WHERE id = ?
        `,
        [
            logo,
            restaurantId
        ]
    );

};

exports.getPlanDetails = async (restaurantId) => {

    return await db.getAsync(
        `
        SELECT

            r.plan_id,

            p.display_name,

            r.subscription_status,

            r.plan_start,

            r.plan_end

        FROM restaurants r

        LEFT JOIN plans p
            ON p.id = r.plan_id

        WHERE r.id = ?
        `,
        [restaurantId]
    );

};
exports.expireSubscription =
async (restaurantId) => {

    await db.runAsync(
        `
        UPDATE restaurants

        SET

            subscription_status =
                'expired',

            updated_at =
                CURRENT_TIMESTAMP

        WHERE id = ?
        `,
        [
            restaurantId
        ]
    );

};

exports.createFromCloud = async (restaurant) => {

    const existing =
    await exports.getById(
        restaurant.id
    );

if (existing) {

    return existing.id;

}

    const result =
        await db.runAsync(
            `
            INSERT INTO restaurants (

                id,
                name,
                owner_name,
                mobile,
                email,
                gst_number,
                fssai_number,
                address,
                city,
                state,
                pincode,
                logo,
                restaurant_code,
                plan_id,
                subscription_status,
                plan_start,
                plan_end,
                trial_used,
                status

            )
            VALUES (

                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?

            )
            `,
            [

                restaurant.id,
                restaurant.name,
                restaurant.owner_name,
                restaurant.mobile,
                restaurant.email,
                restaurant.gst_number,
                restaurant.fssai_number,
                restaurant.address,
                restaurant.city,
                restaurant.state,
                restaurant.pincode,
                restaurant.logo,
                restaurant.restaurant_code,
                restaurant.plan_id,
                restaurant.subscription_status,
                restaurant.plan_start,
                restaurant.plan_end,
                restaurant.trial_used,
                restaurant.status

            ]
        );

    return result.lastID;

};
exports.updateSubscriptionFromCloud = async (
    restaurantId,
    restaurant
) => {

    await db.runAsync(
        `
        UPDATE restaurants
        SET
            plan_id = ?,
            subscription_status = ?,
            plan_start = ?,
            plan_end = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [
            restaurant.plan_id,
            restaurant.subscription_status,
            restaurant.plan_start,
            restaurant.plan_end,
            restaurantId
        ]
    );

};
exports.saveCloudToken = async (
    restaurantId,
    token
) => {

    await db.runAsync(
        `
        UPDATE restaurants

        SET

            cloud_token = ?,

            cloud_token_updated_at =
                CURRENT_TIMESTAMP

        WHERE id = ?
        `,
        [
            token,
            restaurantId
        ]
    );

};

exports.getCloudToken = async (
    restaurantId
) => {

    return await db.getAsync(
        `
        SELECT

            cloud_token

        FROM restaurants

        WHERE id = ?
        `,
        [
            restaurantId
        ]
    );

};
exports.getSubscription = async (
    restaurantId
) => {

    return await db.getAsync(
        `
        SELECT

            r.plan_id,

            p.display_name,

            r.subscription_status,

            r.plan_start,

            r.plan_end

        FROM restaurants r

        LEFT JOIN plans p
            ON p.id = r.plan_id

        WHERE r.id = ?
        `,
        [restaurantId]
    );

};

exports.expireSubscription =
async (restaurantId) => {

    await db.runAsync(
        `
        UPDATE restaurants

        SET

            subscription_status =
                'expired',

            updated_at =
                CURRENT_TIMESTAMP

        WHERE id = ?
        `,
        [
            restaurantId
        ]
    );

};
const db = require("../db");

const getLimit = async (
    planId,
    limitKey
) => {

    return await db.getAsync(
        `
        SELECT
            limit_value
        FROM plan_limits
        WHERE
            plan_id = ?
            AND limit_key = ?
        LIMIT 1
        `,
        [
            planId,
            limitKey
        ]
    );

};

exports.getWaiterDeviceLimit = async (
    planId
) => {

    const limit =
        await getLimit(
            planId,
            "waiter_devices"
        );

    return limit
        ? limit.limit_value
        : null;

};

exports.createFromCloud = async (
    planLimit
) => {

    const existing =
        await getLimit(
            planLimit.plan_id,
            planLimit.limit_key
        );

    if (existing) {

        await db.runAsync(
            `
            UPDATE plan_limits
            SET
                limit_value = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE
                plan_id = ?
                AND limit_key = ?
            `,
            [
                planLimit.limit_value,
                planLimit.plan_id,
                planLimit.limit_key
            ]
        );

        return;

    }

    await db.runAsync(
        `
        INSERT INTO plan_limits
        (
            plan_id,
            limit_key,
            limit_value
        )
        VALUES
        (
            ?,
            ?,
            ?
        )
        `,
        [
            planLimit.plan_id,
            planLimit.limit_key,
            planLimit.limit_value
        ]
    );

};
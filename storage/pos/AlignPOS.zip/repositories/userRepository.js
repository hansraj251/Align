const db =
    require("../db");


exports.getById = async (userId) => {

    return await db.getAsync(
        `
        SELECT *
        FROM users
        WHERE id = ?
        `,
        [
            userId
        ]
    );

};

exports.createFromCloud = async (user) => {

    const existing =
        await exports.getById(
            user.id
        );

    if (existing) {

        return existing.id;

    }

    const result =
        await db.runAsync(
            `
            INSERT INTO users (

                id,
                restaurant_id,
                name,
                email,
                mobile,
                password,
                role,
                status

            )
            VALUES (

                ?, ?, ?, ?, ?, ?, ?, ?

            )
            `,
            [

                user.id,
                user.restaurant_id,
                user.name,
                user.email,
                user.mobile,
                user.password_hash,
                user.role,
                user.status

            ]
        );

    return result.lastID;

};
const db = require("../db");

exports.getById = async (id) => {

    return await db.getAsync(
        `
        SELECT
            id,
            slug,
            display_name,
            description,
            sort_order,
            status,
            created_at,
            updated_at
        FROM plans
        WHERE id = ?
        `,
        [id]
    );

};

exports.createFromCloud = async (plan) => {

    const existing =
        await exports.getById(
            plan.id
        );

    if (existing) {

        await db.runAsync(
            `
            UPDATE plans
            SET

                slug = ?,

                display_name = ?,

                description = ?,

                sort_order = ?,

                status = ?,

                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?
            `,
            [

                plan.slug,

                plan.display_name,

                plan.description,

                plan.sort_order,

                plan.status,

                plan.id

            ]
        );

        return;

    }

    await db.runAsync(
        `
        INSERT INTO plans
        (
            id,
            slug,
            display_name,
            description,
            sort_order,
            status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
        `,
        [

            plan.id,

            plan.slug,

            plan.display_name,

            plan.description,

            plan.sort_order,

            plan.status

        ]
    );

};
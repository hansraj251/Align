const cloudSyncService =
    require("./cloudSyncService");
const restaurantRepository =
    require("../repositories/restaurantRepository");
exports.getSubscriptionSyncData = async (
    restaurantId
) => {

    const token =
        await restaurantRepository
            .getCloudToken(
                restaurantId
            );

    if (
        !token?.cloud_token
    ) {

        throw new Error(
            "Cloud token not found."
        );

    }

    const response =
        await fetch(
            `${process.env.CLOUD_API_URL}/api/subscription/sync`,
            {

                method: "GET",

                headers: {

                    Authorization:
                        `Bearer ${token.cloud_token}`

                }

            }
        );

    if (!response.ok) {

        throw new Error(
            "Subscription sync failed."
        );

    }

    return await response.json();

};
exports.syncSubscription = async (
    restaurantId
) => {

    console.log("Sync Start");

    const response =
        await exports.getSubscriptionSyncData(
            restaurantId
        );

    console.log(
        "Cloud Response:",
        JSON.stringify(response, null, 2)
    );

    if (!response.success) {

        throw new Error(
            response.message
        );

    }

    await cloudSyncService.syncSubscription(
    restaurantId,
    response.data
);

    console.log("Sync End");

};
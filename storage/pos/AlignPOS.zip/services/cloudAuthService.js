const cloudSyncService =
    require("./cloudSyncService");

const POS_API_URL =
    process.env.CLOUD_API_URL;
const restaurantRepository =
    require("../repositories/restaurantRepository");
const cloudApiService =
    require("./cloudApiService");    
exports.login = async (
    email,
    password
) => {

    const response =
        await fetch(
            `${POS_API_URL}/api/pos/login`,
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({

                    email,

                    password

                })

            }
        );

    if (!response.ok) {

        throw new Error(
            "Cloud login failed"
        );

    }

    const data =
        await response.json();

    if (!data.success) {

        throw new Error(
            data.message
        );

    }

    await cloudSyncService.importRestaurant(
        data
    );
    await restaurantRepository.saveCloudToken(

    data.restaurant.id,

    data.token

);
console.log("Calling subscription sync...");
await cloudApiService.syncSubscription(
    data.restaurant.id
);
console.log("Subscription sync completed.");

    return data.user;

};

exports.reLogin = async (
    restaurantId
) => {

    const restaurant =
        await restaurantRepository.getRestaurant();

    if (!restaurant) {

        throw new Error(
            "Restaurant not found."
        );

    }

    return await exports.login(

        restaurant.email,

        restaurant.password

    );

};
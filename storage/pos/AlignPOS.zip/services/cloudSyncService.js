const db =
    require("../db");

const restaurantRepository =
    require("../repositories/restaurantRepository");

const planRepository =
    require("../repositories/planRepository");

const planLimitRepository =
    require("../repositories/planLimitRepository");

const userRepository =
    require("../repositories/userRepository");
const settingsRepository =
    require("../repositories/settingsRepository"); 

exports.importRestaurant = async (data) => {

    try {

        await db.transaction(async () => {
            await planRepository.createFromCloud(data.plan);

            await planLimitRepository.createFromCloud(data.planLimit);

            await restaurantRepository.createFromCloud(data.restaurant);

            await settingsRepository.createDefaultSettings(
    data.restaurant
);

            await userRepository.createFromCloud(data.user);

        });


    } catch (err) {


        throw err;

    }

};

exports.syncSubscription = async (
    restaurantId,
    data
) => {

    await db.transaction(
        async () => {

            await planRepository.createFromCloud(
                data.plan
            );

            await planLimitRepository.createFromCloud(
                data.planLimit
            );

            await restaurantRepository.updateSubscriptionFromCloud(
                restaurantId,
                data.restaurant
            );

        }
    );

};
const tableRepository =
    require("../repositories/tableRepository");
const diningAreaRepository =
    require("../repositories/diningAreaRepository");  
const orderRepository =
    require("../repositories/orderRepository");      

exports.getAll = async (
    restaurantId
) => {

    return await tableRepository.getAll(
        restaurantId
    );

};

exports.create = async (
    restaurantId,
    data
) => {

    const name =
        (data.name || "").trim();

    if (!name) {

        throw new Error(
            "Table name is required"
        );

    }

    const existing =
        await tableRepository.getByName(
            restaurantId,
            name
        );

    if (existing) {

        throw new Error(
            "Table name already exists"
        );

    }


if (data.area_id) {

    const area =
        await diningAreaRepository.getById(
            restaurantId,
            data.area_id
        );

    if (!area) {

        throw new Error(
            "Invalid dining area"
        );

    }

}
    const tableId =
        await tableRepository.create(

            restaurantId,

            name,

            data.capacity,

            data.area_id || null

        );

    return {

        success: true,

        message:
            "Table created successfully",

        tableId

    };

};

exports.delete = async (
    restaurantId,
    tableId
) => {
   const table =
    await tableRepository.getById(
        restaurantId,
        tableId
    );

if (table.system_key === "takeaway") {

    throw new Error(
        "Default Take Away table cannot be deleted."
    );

} 

    const activeOrders =
        await orderRepository.getActiveOrdersByTable(
            tableId,
            0
        );

    if (activeOrders > 0) {

        throw new Error(
            "Cannot delete table with an active order"
        );

    }

    const result =
        await tableRepository.delete(

            restaurantId,

            tableId

        );

    if (result.changes === 0) {

        throw new Error(
            "Table not found"
        );

    }

    return {

        success: true,

        message:
            "Table deleted successfully"

    };

};

exports.update = async (
    restaurantId,
    tableId,
    data
) => {

    const table =
        await tableRepository.getById(
            restaurantId,
            tableId
        );

    if (!table) {

        throw new Error(
            "Table not found"
        );

    }

    const name =
        (data.name || "").trim();
        

    if (!name) {

        throw new Error(
            "Table name is required"
        );

    }
    const existing =
    await tableRepository.getByNameExceptId(

        restaurantId,

        name,

        tableId

    );

if (existing) {

    throw new Error(
        "Table name already exists"
    );

}
    const capacity =
    Number(data.capacity);
    const displayRow =
    Number(data.display_row);

if (
    !Number.isInteger(displayRow) ||
    displayRow < 1
) {

    throw new Error(
        "Display Row must be at least 1"
    );

}

if (
    !Number.isInteger(capacity) ||
    capacity < 1
) {

    throw new Error(
        "Capacity must be at least 1"
    );

}

    if (data.area_id) {

        const area =
            await diningAreaRepository.getById(
                restaurantId,
                data.area_id
            );

        if (!area) {

            throw new Error(
                "Invalid dining area"
            );

        }

    }

    await tableRepository.update(

    restaurantId,

    tableId,

    name,

    data.capacity || 4,

    data.area_id || null,

   displayRow

);

    return {

        success: true,

        message:
            "Table updated successfully"

    };

};

exports.getTakeAwayTable = async (
    restaurantId
) => {

    return await tableRepository.getTakeAwayTable(
        restaurantId
    );

};

exports.reserveTable = async (
    restaurantId,
    tableId,
    reservedName
) => {

    const table =
        await tableRepository.getById(
            restaurantId,
            tableId
        );

    if (!table) {

        throw new Error(
            "Table not found"
        );

    }

    reservedName =
        (reservedName || "").trim();

    if (!reservedName) {

        throw new Error(
            "Customer name is required"
        );

    }

    if (table.is_reserved) {

        throw new Error(
            "Table is already reserved"
        );

    }

    await tableRepository.reserveTable(
        restaurantId,
        tableId,
        reservedName
    );

    return {

        success: true,

        message:
            "Table reserved successfully"

    };

};

exports.clearReservation = async (
    restaurantId,
    tableId
) => {

    const table =
        await tableRepository.getById(
            restaurantId,
            tableId
        );

    if (!table) {

        throw new Error(
            "Table not found"
        );

    }

    if (!table.is_reserved) {

        throw new Error(
            "Table is not reserved"
        );

    }

    await tableRepository.clearReservation(
        restaurantId,
        tableId
    );

    return {

        success: true,

        message:
            "Reservation cleared successfully"

    };

};
exports.updateLock = async (
    restaurantId,
    tableId,
    isLocked
) => {

    const table =
        await tableRepository.getById(
            restaurantId,
            tableId
        );

    if (!table) {

        throw new Error(
            "Table not found"
        );

    }

    const activeOrders =
        await orderRepository.getActiveOrdersByTable(
            tableId,
            0
        );

    if (
        isLocked &&
        activeOrders > 0
    ) {

        throw new Error(
            "Cannot lock table with an active order"
        );

    }

    await tableRepository.updateLock(
        restaurantId,
        tableId,
        isLocked ? 1 : 0
    );

    return {

        success: true,

        message: isLocked
            ? "Table locked successfully"
            : "Table unlocked successfully"

    };

};
exports.createBulk = async (
    restaurantId,
    data
) => {

    const prefix =
        (data.prefix || "").trim();

    const count =
        Number(data.count);

    const capacity =
        Number(data.capacity || 4);

    if (!prefix) {

        throw new Error(
            "Table prefix is required"
        );

    }

    if (
        !Number.isInteger(count) ||
        count < 1
    ) {

        throw new Error(
            "Invalid table count"
        );

    }

    if (
        !Number.isInteger(capacity) ||
        capacity < 1
    ) {

        throw new Error(
            "Capacity must be at least 1"
        );

    }

    if (data.area_id) {

        const area =
            await diningAreaRepository.getById(
                restaurantId,
                data.area_id
            );

        if (!area) {

            throw new Error(
                "Invalid dining area"
            );

        }

    }

    const tables =
        await tableRepository.getByArea(
            restaurantId,
            data.area_id
        );

    let highest = 0;

    const regex =
        new RegExp(
            `^${prefix}\\s*(\\d+)$`,
            "i"
        );

    tables.forEach(table => {

        const match =
            table.name.match(regex);

        if (match) {

            highest =
                Math.max(
                    highest,
                    Number(match[1])
                );

        }

    });

    for (
        let i = 1;
        i <= count;
        i++
    ) {

        await tableRepository.create(

            restaurantId,

            `${prefix} ${highest + i}`,

            capacity,

            data.area_id

        );

    }

    return {

        success: true,

        message:
            `${count} tables created successfully`

    };

};